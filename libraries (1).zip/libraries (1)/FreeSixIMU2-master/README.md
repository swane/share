# FreeSixIMU2
An updated version of the FreeSixIMU library for the Sparkfun 6DOF IMU.  This version works with the Arduino Due as well as earlier Arduinos. 
