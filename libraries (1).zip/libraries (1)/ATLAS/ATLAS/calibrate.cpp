#include<ATLAS.h>


#include "Arduino.h"
#include "calibrate.h"
#define btn_adv 1
#define btn_select 2
double _ATLASLt, _ATLASLn;

double _ATLASdistance, _ATLASbearing,  _ATLASgoal_bear;
void ATLASshow_GPS()
{
  while (1) {
    double lt, ln;

    lt = getLat();
    ln = getLon();
    lcd.clear();
    lcd.print(lt, 6);
    lcd.setCursor(0, 1);
    lcd.print(ln, 6);
    delay(1000);
  }
}


void ATLASshow_bearing() {
  while (1) {
    double bearing = read_compass();

    display("Bearing", String(bearing));
    delay(100);
  }
}
void calibratemenu() {
  String a = ">";
  int menutitle = 0;
  int maxmenutitle = 4;
  int menuitem = 1;
  int maxmenu[4] = {5, 4, 3, 3};


  String menu[4][7] = { {"Display", "GPS", "Bearing", "Front pot", "Rear Pot", "Temperature" },
    {"Calbrte Steer", "Front steer", "Rear steer", "Max Fr Steer", "Max Rr Steer"},
    {"Calbrte Sensor", "CompassGPS", "Compass Magnetic", "A1 Low:", "A1 High:", "" },
    {"PID", "Kp:", "Ki:", "Kd:", "Reset", "Save" },
  };
  int mode = 0;
  display(a + menu[menutitle][0], menu[0][1]);
  while (1) {
    if (edge_rising( btn_adv)) {
      if (mode == 0)
      {

        menutitle++;
        if (menutitle == maxmenutitle)menutitle = 0;
        display(a + menu[menutitle][0], menu[menutitle][menuitem]);
      }
      if (mode == 1) {
        menuitem++;
        if (menuitem > maxmenu[menutitle]) menuitem = 1;
        display(menu[menutitle][0], a + menu[menutitle][menuitem]);
      }
    }
    if (edge_rising(btn_select)) {
      if (mode == 1) {
        lcd.clear();
        //display("SELECTED!");
        if ((menutitle == 1) && (menuitem == 1)) calibratefrontsteer();
        if ((menutitle == 1) && (menuitem == 2)) calibraterearsteer();
        if ((menutitle == 0) && (menuitem == 1)) ATLASshow_GPS();
        if ((menutitle == 0) && (menuitem == 2)) ATLASshow_bearing();
        if ((menutitle == 2) && (menuitem == 1)) show_calib_compass();
        if ((menutitle == 2) && (menuitem == 2)) ATLASmagcalcompass();
        //menuitem++;
        //display(menu[menutitle][0], a + menu[menutitle][menuitem]);
      }
      if (mode == 0) {
        display(menu[menutitle][0], a + menu[menutitle][menuitem]);
        mode = 1; delay(100);
      }
    }

  }
}

void calibratefrontsteer()
{
  int ATLAS_front_steer_angle = 0;
  display("1=+, 3=-", "2=Store (" + String(ATLAS_front_steer_angle) + ")");
  delay(200);
  while (1) {
    int fr_offset;
    if (edge_rising(1)) {
      led_out(1, ON); delay(100); led_out(1, OFF);
      ATLAS_front_steer_angle--;
      steer(ATLAS_front_steer_angle );
      display("1=+, 3=-", "2=Store (" + String(ATLAS_front_steer_angle) + ")");
    }
    if (edge_rising(3)) {
      led_out(1, ON); delay(100); led_out(1, OFF);
      ATLAS_front_steer_angle++;
      steer(ATLAS_front_steer_angle );
      display("1=+, 3=-", "2=Store (" + String(ATLAS_front_steer_angle) + ")");
    }

    if (edge_rising(2)) {
      display("Storing Front", "Centre off:" + String(ATLAS_front_steer_angle));
      fr_offset = (ATLAS_front_steer_angle) + read_front_calibrate();

      int o;
      o = fr_offset;
      if (fr_offset < 0) o = 128 - fr_offset; //neg numbers are 128+
      byte b = (byte)o;

      EEPROM.write(1, b);
      EEPROM.write(0, 170); //number to represent calibration has occurred

      set_front_calibrate(read_front_calibrate() + ATLAS_front_steer_angle);
      ATLAS_front_steer_angle = 0;
      delay(2000);
    }
  }
}
void calibraterearsteer()
{
  int ATLAS_front_steer_angle = 0;
  display("1=+, 3=-", "2=Store (" + String(ATLAS_front_steer_angle) + ")");
  delay(200);
  while (1) {
    int fr_offset;
    if (edge_rising(1)) {
      led_out(1, ON); delay(100); led_out(1, OFF);
      ATLAS_front_steer_angle--;
      rear_steer(ATLAS_front_steer_angle );
      display("1=+, 3=-", "2=Store (" + String(ATLAS_front_steer_angle) + ")");
    }
    if (edge_rising(3)) {
      led_out(1, ON); delay(100); led_out(1, OFF);
      ATLAS_front_steer_angle++;
      rear_steer(ATLAS_front_steer_angle );
      display("1=+, 3=-", "2=Store (" + String(ATLAS_front_steer_angle) + ")");
    }

    if (edge_rising(2)) {
      display("Storing Front", "Centre off:" + String(ATLAS_front_steer_angle));
      fr_offset = (ATLAS_front_steer_angle) + read_front_calibrate();

      int o;
      o = fr_offset;
      if (fr_offset < 0) o = 128 - fr_offset; //neg numbers are 128+
      byte b = (byte)o;

      EEPROM.write(2, b);
      EEPROM.write(0, 170); //number to represent calibration has occurred
      set_rear_calibrate(read_rear_calibrate() + ATLAS_front_steer_angle);

      rear_steer(0);

      ATLAS_front_steer_angle = 0;
      delay(2000);
    }
  }
}


void ATLASshow_location()
{

  lcd.clear();
  lcd.print(_ATLASLt, 6);
  lcd.setCursor(0, 1);
  lcd.print(_ATLASLn, 6);

}
void calib_ATLASshow_bearing()
{

  lcd.clear();
  lcd.print(_ATLASdistance);
  lcd.setCursor(0, 1);
  lcd.print(_ATLASgoal_bear); lcd.print(" : "); lcd.print(_ATLASbearing); delay(200);

}


void show_calib_compass()
{
  double goal_lat, goal_lon;
  static int state = 0;
  lcd.clear();
  display("Move to location", "Press btn 2"); delay(2000);

  set_timer(0, 200);
  while (1) {
    if (state == 0)
    {
      if (timer_elapsed(0))
      {
        _ATLASLt = getLat();
        _ATLASLn = getLon();
        ATLASshow_location();

        _ATLASdistance = distance_to_point_deg(_ATLASLt, _ATLASLn, goal_lat, goal_lon);
        _ATLASgoal_bear = bearing_to_point_deg(_ATLASLt, _ATLASLn, goal_lat, goal_lon);
        set_timer(0, 500);
      }
      if (edge_rising(2)) {
        goal_lat = getLat();
        goal_lon = getLon();
        display("Distance", "GPS B:Current B");
        delay(2000);
        state = 1;
      }
    }
    if (state == 1)
    {
      if (timer_elapsed(0))
      {
        _ATLASLt = getLat();
        _ATLASLn = getLon();


        _ATLASdistance = distance_to_point_deg(_ATLASLt, _ATLASLn, goal_lat, goal_lon);
        _ATLASgoal_bear = bearing_to_point_deg(_ATLASLt, _ATLASLn, goal_lat, goal_lon);

        set_timer(0, 500);
      }
      ATLAScalib_compass();
      _ATLASbearing = read_compass();
      calib_ATLASshow_bearing();
    }
  }
}

void ATLAScalib_compass() {

  double ob;
  if (edge_rising(1)) {
    ob = read_offset_bearing();
    ob = ob - 1;
    write_offset_bearing(ob);
    ob = read_offset_bearing();
  }
  if (edge_rising(3)) {

    ob = read_offset_bearing();
    ob = ob + 1;
    write_offset_bearing(ob);
    ob = read_offset_bearing();
  }
  if (edge_rising(2)) {
    write_offset_bearing(0);
    ob = read_offset_bearing();
  }

}

void ATLASmagcalcompass() {
  while (1) {
    lcd.print("1-Del Cal,2-Sto Cal");
    if (read_button(1))del_compass_cal();
    if (read_button(2))store_compass_cal();

    double b;
    unsigned char c;

    b = read_compass();
    c = read_compass_cal();
    nextline_LCD();
    lcd.print(b);
    lcd.print(" Cal:");
    lcd.print(c);

    delay(100);
  }
}